--Total lead;
select count(l.`Alyssa has been Notified`)
from lead_table l;

out put :
'10000'


select ot.`Expected Amount`
from opportunity_table ot join lead_table l
on l.`Converted Account ID` = ot.`Account ID`;

--Expected Amount ;
SELECT sum(CAST(REPLACE(ot.`Expected Amount`, '$', '') AS DECIMAL(10, 2))) AS amount
FROM opportunity_table ot;

Out put:
'184143968.97'


--Conversion_Rate_Percentage;

select count(`Alyssa has been Notified`) from lead_table;

select count(`# Converted Accounts`) from lead_table;

SELECT (count(`Converted Account ID`) / count(`Alyssa has been Notified`)) * 100 AS Conversion_Rate_Percentage
FROM lead_table;

out put :
'10.1600'


--Converted Accounts ;

select count(`Converted Account ID`) converted_accounts
from lead_table;

out put :
'1016'

--Converted_Opportunities;

select count(`ï»¿Account ID`) Converted_Opportunities
from opportunity_table
where `Stage` = 'Closed Won';

Out put : '1443'


--lead by source;

select `Lead Source`, count(`Lead Source`) as leads
from lead_table
group by `Lead Source`
order by leads desc;

out put :
Inside Sales	2786
Website	2195
Trade Show	1610
Webinar	1091
Advertisement	613
Field Sales	577
Prospecting Journey	440
Eblasts	298
Sales Seminar	207
Other	47
Referral	20
Industry Event	18
Google Natural Search	17
Social	15
Advertisment	11
Training	7
LinkedIn	6
Trades Show	6
Banner Ads	5
eApp Note	4
Twitter	4
Bing Natural Search	2
Eblast	1
Service	1
Key Account Event	1
Organic Social	1
Advertising	1
	0

--Lead By industry;

select `Industry` , count(`Industry`) as leads
from lead_table
group by `Industry`
order by leads desc;

out put :
Safety and Security	5357
Life Sciences	4120
Distributor	98
Other	83
Biotechnology	47
Apparel	44
Banking	41
Agriculture	32
Chemicals	30
Communications	26
Environmental	25
Consulting	15
Oil & Gas	15
Construction	5
Telecommunications	2
Retail	2
Cannabis	2
Hydrocarbon Processing	1
Rebel	1
Applied Markets	1
	0

--Leads by Stage;

select ot.`Stage`, count(ot.`Stage`) stages_count
from lead_table l join opportunity_table ot
on l.`Converted Account ID` = ot.`ï»¿Account ID`
group by ot.Stage
order by stages_count desc;

Out put :
Closed Won	1854
Closed Lost	1450
Funnel	288
Quoted Funnel	131
Qualified Opportunity	121
Customer Assessment w/ Favorable Evaluation	79
Upside	57
Decision to Purchase	36
Commit	20
Order Expected within 90 Days	18
Order Expected within 30 Days	12

Opportunity Dashboard -

--Expected Amount ;
SELECT sum(CAST(REPLACE(ot.`Expected Amount`, '$', '') AS DECIMAL(10, 2))) AS amount
FROM opportunity_table ot;

Out put:
'184143968.97'

--Active Opportunities-Total count of open opportunities;
select count(`Closed`) Active_Opportunity
from opportunity_table
where `Closed` = 'false';

Out Put 

1272

--Conversion Rate-Conversion Rate (%);

SELECT (count(case when `Stage` = 'Closed Won' then 1 end)* 100) / count(*) AS Conversion_Rate_Percentage 		 	
FROM opportunity_table;

Out put 
31.0590

select count(`Stage`) total_closed_won
from opportunity_table
where Stage = 'Closed Won';    

--Win Rate-Win Rate (%);

SELECT (count(case when `Stage` = 'Closed Won' then 1 end)* 100) / count(*) AS Conversion_Rate_Percentage 		 	
FROM opportunity_table;

Out put 
31.0590

-- Loss Rate-Loss Rate (%);
SELECT (count(case when `Stage` = 'Closed lost' then 1 end)* 100) / count(*) AS Conversion_Rate_Percentage 		 	
FROM opportunity_table;

out put 
41.5626

-- Expected Vs Forecast;

select `Fiscal Year`, sum(`Amount`) forecasted_Amount, sum(`Expected Amount`) expected_Amount
from opportunity_table
group by `Fiscal Year`;

out put

2015	6549762.95	1294489.95
2016	84847162.25	20338334.75
2019	135476963.36999995	14421915.19
2018	41379399.50000001	8364394.96
2021	375002398.1200002	75592117.29
2017	27285823.800000004	5558238.399999999
2022	37243761.94	6669138.360000003
2020	310601083.29	51144006.419999994
2023	2865123.14	159813.65
2024	73600	51520
2011	920000	550000
2025	0	0
2030	270000	0

--Active Vs Total Opportunities;
select `Fiscal Year`, count(case when `Stage` = 'closed won' then 1 end) Active_opportunity, count(case when `Stage` is not null then 1 end) Total_Opportunities
from opportunity_table
group by `Fiscal Year`;

2015	16	48
2016	60	144
2019	324	624
2018	166	567
2021	294	1381
2017	136	438
2022	0	262
2020	445	1162
2023	0	10
2024	0	1
2011	2	7
2025	0	1
2030	0	1

--Active Vs Total Opportunities: ;
select `Fiscal Year`, count(case when `Closed` = 'false' then 1 end) Active_opportunity, count(case when `Closed` is not null then 1 end) Total_Opportunities
from opportunity_table
group by `Fiscal Year`;

out put 

2015	0	48
2016	13	144
2019	3	624
2018	1	567
2021	741	1381
2017	171	438
2022	232	262
2020	103	1162
2023	7	10
2024	1	1
2011	0	7
2025	0	1
2030	0	1

--Closed Won Vs Total Opportunities;

select `Fiscal Year`, count(case when `Stage` = 'Closed Won' then 1 end) Closed_Won_opportunity, count(case when `Closed` is not null then 1 end) Total_Opportunities
from opportunity_table
group by `Fiscal Year`;

out put

2015	16	48
2016	60	144
2019	324	624
2018	166	567
2021	294	1381
2017	136	438
2022	0	262
2020	445	1162
2023	0	10
2024	0	1
2011	2	7
2025	0	1
2030	0	1


-- Closed Won Vs Total Closed;

select `Fiscal Year`, count(case when `Stage` = 'Closed Won' then 1 end) Closed_Won_opportunity, count(case when `Stage` in ('Closed Won', 'Closed lost' ) then 1 end) Total_Opportunities
from opportunity_table
group by `Fiscal Year`;

out put
2015	16	48
2016	60	131
2019	324	621
2018	166	566
2021	294	640
2017	136	267
2022	0	30
2020	445	1059
2023	0	3
2024	0	0
2011	2	7
2025	0	1
2030	0	1

--Expected Amount by Opportunity Type;

select `Opportunity Type`, sum(`Expected Amount`)
from opportunity_table
group by `Opportunity Type`;

out put

	179388519.00000012
Safety and Security Opportunity	4205449.97
Existing Business	50000
New Business	500000


-- Opportunities by Industry;

select `Industry`, count(case when `Industry` is not null then 1 end) Total_Opportunities
from opportunity_table
group by `Industry`
order by Total_Opportunities desc;

out put

Biopharma/Pharmaceuticals	1143
State and Local	558
International	264
Federal	231
Communications	229
Energy	194
Military	187
Academia	182
Biotechnology	174
Agriculture	164
Telecommunications	137
Construction	112
Banking	108
Apparel	88
Other	82
Hospitality	79
Transportation	76
Education	63
Electronics	54
Chemicals	51
Consulting	50
Distributor	41
Government	28
CRO / CDMO	8
Commercial	8
Life Science Research	7
Biopharma/Biopharmaceuticals	2
State	1
Municipal	1
CDMOs	1
State & Local	1
Law Enforcement	1
	0
